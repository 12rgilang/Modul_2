1. State
Basicly mirip seperti variable. Hanya saja dia dapat membuat component menjadi dinamis. Setiap terjadi perubahan data, component akan di render ulang.